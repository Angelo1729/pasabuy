# Pasabuy — Flutter App

Generated from the Figma file **Pasabuy** (`IofdZau8KpMybfZx49Wz9b`).
"Hop On the Purchase." — a buy-for-me / errand delivery app for two roles:
**Requester** (needs something bought) and **Shopper** (goes to the store and
earns by delivering).

## Screens included

- **Onboarding**: Splash → Login → Create Account (3 steps: basic info,
  set location on map, choose Requester/Shopper role)
- **Home**: current-mode pill + a "nearby shoppers" radar/map view
- **Transactions**: filterable, date-grouped transaction history
- **Chats**: conversation list + a chat detail screen with message bubbles
- **Profile**: wallet balance (deposit/withdraw), current activity mode
  toggle, and an account settings menu

## Design tokens (from the Figma "Colors" frame)

| Token   | Hex       |
|---------|-----------|
| Primary | `#7C3AED` |
| Accent  | `#8B5CF6` |
| Surface | `#F5F3FF` |
| Text    | `#111827` |

These live in `lib/theme/app_theme.dart`.

## Project structure

```
lib/
  main.dart                 # App entry point
  theme/app_theme.dart      # Colors + ThemeData
  widgets/                  # Reusable pieces (pill inputs, buttons, nav, etc.)
  screens/                  # One file per screen
```

## Running it in VS Code

1. Install the **Flutter** and **Dart** VS Code extensions.
2. Make sure the Flutter SDK is installed (`flutter doctor` should pass).
3. Open this folder in VS Code.
4. Run:
   ```bash
   flutter pub get
   flutter run
   ```
5. Pick a simulator/emulator/device from the VS Code status bar (bottom
   right) or run `flutter run -d chrome` to preview in a browser.

## Notes / next steps

- The map views (Home radar, Set Location step) are stylized placeholders —
  swap in `google_maps_flutter` or `flutter_map` and wire up real
  coordinates when you're ready.
- Sample/demo data (transactions, chats, wallet balance) is hard-coded in
  each screen's widget — replace with real API calls / state management
  (Provider, Riverpod, Bloc, etc.) as the backend comes online.
- Fonts use `google_fonts` (Roboto), matching the Figma type styles.
