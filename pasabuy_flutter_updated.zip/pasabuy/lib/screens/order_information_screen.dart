import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';
import 'chat_detail_screen.dart';
import 'payment_option_screen.dart';

/// Which Figma frame the Order Information screen renders.
enum OrderVariant {
  /// "Order [Requester's Screen]" — shopper card, GCash, Select Payment Method.
  requester,

  /// "Order [Shopper's Screen]" — requester card, COD, scan button.
  shopper,

  /// "Order History" — completed order, summary in a card, no action button.
  history,
}

class OrderInformationScreen extends StatelessWidget {
  const OrderInformationScreen({super.key, required this.variant});

  final OrderVariant variant;

  static const _orderNumber = '65017406610472610';

  bool get _isRequester => variant == OrderVariant.requester;

  @override
  Widget build(BuildContext context) {
    final party = _PartySummary(variant: variant);
    return Scaffold(
      backgroundColor: AppColors.bgCanvas,
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(20, screenTopPadding(context), 20, 16),
              child: Column(
                children: [
                  const DetailHeader(title: 'Order Information'),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: 334,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isRequester ? '[Name] has accepted your request' : 'You accepted [Name]’s request',
                          style: AppText.medium(20, Colors.black),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Order number:', style: AppText.regular(12, AppColors.muted)),
                            GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => Clipboard.setData(const ClipboardData(text: _orderNumber)),
                              child: Row(
                                children: [
                                  Text(_orderNumber, style: AppText.regular(12, AppColors.muted)),
                                  const SizedBox(width: 4),
                                  const AppSvg(AppAssets.copy, width: 11, height: 11),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _TripInfoCard(steps: _isRequester ? _requesterSteps : _shopperSteps),
                  const SizedBox(height: 16),
                  _OrderDetailsCard(fixedHeight: variant != OrderVariant.history),
                  if (variant == OrderVariant.history) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.border15, width: 0.5),
                      ),
                      child: party,
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (variant != OrderVariant.history)
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: AppColors.border15, width: 0.5),
              ),
              padding: EdgeInsets.fromLTRB(
                20,
                10,
                20,
                math.max(36.0, MediaQuery.paddingOf(context).bottom + 12),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  party,
                  const SizedBox(height: 16),
                  _isRequester
                      ? PrimaryButton(
                          label: 'Select Payment Method',
                          onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const PaymentOptionScreen()),
                          ),
                        )
                      : PrimaryButton(
                          onPressed: () {},
                          child: const AppSvg(AppAssets.scan, width: 18, height: 18),
                        ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

const _requesterSteps = [
  'Accepted your request',
  'On the way to the store',
  'Picking your items',
  'Proceeds to line at the cashier',
  'Paid your items bought',
  'On the way to deliver your items',
];

const _shopperSteps = [
  'Accepted [Name]’s request',
  'On the way to the store',
  'Picking requester’s items',
  'Proceeds to line at the cashier',
  'Paid requester’s items bought',
  'On the way to deliver requester’s items',
];

/// "Trip Info": white 246px card with the vertical tracker. The tracker is
/// taller than the card, so it scrolls, with the white inner glow fading the
/// edges like the design.
class _TripInfoCard extends StatelessWidget {
  const _TripInfoCard({required this.steps});

  final List<String> steps;

  static const _dotTops = [4.12, 67.31, 134.31, 197.31, 262.31, 326.31];
  static const _rowTops = [0.0, 65.0, 130.0, 195.0, 260.0, 325.0];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 246,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border15, width: 0.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(29, 27, 0, 27),
              child: SizedBox(
                width: 292,
                height: 363,
                child: Stack(
                  children: [
                    Positioned(
                      left: -0.05,
                      top: 2.42,
                      width: 18.283,
                      height: 341.174,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(143),
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [AppColors.trackerTop, AppColors.primary],
                          ),
                        ),
                      ),
                    ),
                    for (final top in _dotTops)
                      Positioned(
                        left: 1.4,
                        top: top - 0.31,
                        child: const AppSvg(AppAssets.trackDot, width: 16, height: 16),
                      ),
                    for (var i = 0; i < steps.length; i++)
                      Positioned(
                        left: 35.31,
                        top: _rowTops[i],
                        width: 257,
                        child: _TrackerRow(
                          status: steps[i],
                          alignEnd: i < 2,
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const Positioned.fill(child: IgnorePointer(child: _InnerGlow())),
          ],
        ),
      ),
    );
  }
}

class _TrackerRow extends StatelessWidget {
  const _TrackerRow({required this.status, required this.alignEnd});

  final String status;
  final bool alignEnd;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: 179,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('First Name', style: AppText.regular(8, AppColors.ink)),
              const SizedBox(height: 1),
              Text(status, style: AppText.medium(12, AppColors.ink)),
            ],
          ),
        ),
        const SizedBox(width: 33),
        Text('9:21 AM', style: AppText.regular(12, AppColors.ink)),
      ],
    );
  }
}

/// Approximates the inset white shadow (0 0 6.4px 19px white) on Trip Info.
class _InnerGlow extends StatelessWidget {
  const _InnerGlow();

  static const _stops = [0.0, 0.75, 1.0];
  static const _colors = [Colors.white, Colors.white, Color(0x00FFFFFF)];
  static const _size = 25.0;

  @override
  Widget build(BuildContext context) {
    Widget strip(Alignment begin, Alignment end) => DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: begin, end: end, colors: _colors, stops: _stops),
          ),
        );
    return Stack(
      children: [
        Positioned(left: 0, right: 0, top: 0, height: _size, child: strip(Alignment.topCenter, Alignment.bottomCenter)),
        Positioned(left: 0, right: 0, bottom: 0, height: _size, child: strip(Alignment.bottomCenter, Alignment.topCenter)),
        Positioned(left: 0, top: 0, bottom: 0, width: _size, child: strip(Alignment.centerLeft, Alignment.centerRight)),
        Positioned(right: 0, top: 0, bottom: 0, width: _size, child: strip(Alignment.centerRight, Alignment.centerLeft)),
      ],
    );
  }
}

/// "Order Details": Name / Qty / Price table.
class _OrderDetailsCard extends StatelessWidget {
  const _OrderDetailsCard({required this.fixedHeight});

  final bool fixedHeight;

  static const _items = [
    ('Bearbrand 300G', '2', '654.00'),
    ('Savemore Egg 12PCS', '1', '124.00'),
    ('Coke Zero  1L', '1', '56.00'),
  ];

  @override
  Widget build(BuildContext context) {
    final head = AppText.medium(12, AppColors.ink);
    final cell = AppText.regular(12, AppColors.ink);
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: fixedHeight ? 198 : 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border15, width: 0.5),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 294,
            child: Row(
              children: [
                Expanded(child: Text('Name', style: head)),
                SizedBox(
                  width: 112,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('Qty', style: head), Text('Price', style: head)],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const HairlineDivider(width: 292.369),
          const SizedBox(height: 12),
          SizedBox(
            width: 294,
            child: Column(
              children: [
                for (var i = 0; i < _items.length; i++) ...[
                  if (i > 0) const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(child: Text(_items[i].$1, style: cell)),
                      SizedBox(
                        width: 112,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [Text(_items[i].$2, style: cell), Text(_items[i].$3, style: cell)],
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Counter-party card plus the payment summary ("Mode 1" in Figma).
class _PartySummary extends StatelessWidget {
  const _PartySummary({required this.variant});

  final OrderVariant variant;

  @override
  Widget build(BuildContext context) {
    final isRequester = variant == OrderVariant.requester;
    void openChat() => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ChatDetailScreen()),
        );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            const AvatarPlaceholder(),
            const SizedBox(width: 15.7),
            Expanded(
              child: SizedBox(
                height: 53,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(isRequester ? 'Shopper' : 'Requester', style: AppText.regular(12, AppColors.muted)),
                    Text('Mikaela Surname', style: AppText.medium(14, Colors.black)),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          decoration: BoxDecoration(
                            color: isRequester ? AppColors.gcashBlue : AppColors.success,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            isRequester ? 'GCash' : 'COD',
                            style: AppText.medium(8, AppColors.bgCanvas),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          isRequester ? 'Partial Payment' : 'Cash on Delivery',
                          style: AppText.regular(12, Colors.black),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            if (!isRequester) ...[
              GestureDetector(onTap: () {}, child: const AppSvg(AppAssets.actionPin, width: 17, height: 19)),
              const SizedBox(width: 15),
            ],
            GestureDetector(onTap: () {}, child: const AppSvg(AppAssets.actionPhone, width: 16, height: 16)),
            const SizedBox(width: 16),
            GestureDetector(onTap: openChat, child: const AppSvg(AppAssets.actionChat, width: 20, height: 19)),
          ],
        ),
        const SizedBox(height: 16),
        const HairlineDivider(width: 325.2),
        const SizedBox(height: 16),
        _SummaryRow('Total Payment', '₱350.00', AppText.regular(12, Colors.black)),
        const SizedBox(height: 8),
        isRequester
            ? _SummaryRow('Down Payment', ' - (Total x 30% + ₱60 DF)', AppText.regular(12, AppColors.muted))
            : _SummaryRow('Cash on Delivery', ' - ₱0.00', AppText.regular(12, AppColors.muted)),
        const SizedBox(height: 8),
        _SummaryRow(
          'Remaining Balance',
          isRequester ? '₱ 122.00' : ' ₱350.00',
          AppText.medium(12, AppColors.muted),
        ),
      ],
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow(this.label, this.value, this.style);

  final String label;
  final String value;
  final TextStyle style;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(label, style: style), Text(value, style: style)],
    );
  }
}
