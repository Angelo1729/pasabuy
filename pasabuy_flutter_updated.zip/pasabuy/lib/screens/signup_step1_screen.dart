import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/app_text_field.dart';
import '../widgets/auth_scaffold.dart';
import '../widgets/step_progress.dart';
import 'login_screen.dart';
import 'signup_step2_screen.dart';

/// Create Account Screen Step 1 — personal details.
class SignupStep1Screen extends StatelessWidget {
  const SignupStep1Screen({super.key});

  @override
  Widget build(BuildContext context) {
    const border = AppColors.inputBorderAlt;
    return AuthScaffold(
      padding: const EdgeInsets.fromLTRB(39.23, 112.5, 29.77, 32),
      swooshOffset: const Offset(32.57, 18.81),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const StepProgress(step: 1),
          const SizedBox(height: 29),
          Text('Create Account', style: AppText.bold(32)),
          const SizedBox(height: 14),
          Row(
            children: [
              Text('Already have an account?', style: AppText.regular(14, AppColors.bodyText)),
              const SizedBox(width: 5),
              GestureDetector(
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                ),
                child: Text('Login', style: AppText.regular(14, AppColors.primary)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const AppTextField(hint: 'First Name', iconAsset: AppAssets.person, borderColor: border),
          const SizedBox(height: 14),
          const AppTextField(hint: 'Last Name', iconAsset: AppAssets.person, borderColor: border),
          const SizedBox(height: 14),
          const AppTextField(
            hint: '(+63) 9XX XXX XXXX',
            iconAsset: AppAssets.phone,
            keyboardType: TextInputType.phone,
            borderColor: border,
          ),
          const SizedBox(height: 14),
          const AppTextField(
            hint: 'Email',
            iconAsset: AppAssets.mail,
            keyboardType: TextInputType.emailAddress,
            borderColor: border,
          ),
          const SizedBox(height: 14),
          const AppTextField(hint: 'Password', iconAsset: AppAssets.lock, obscure: true, borderColor: border),
          const SizedBox(height: 14),
          const AppTextField(
            hint: 'Confirm Password',
            iconAsset: AppAssets.lock,
            obscure: true,
            borderColor: border,
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: 'Next',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SignupStep2Screen()),
            ),
          ),
        ],
      ),
    );
  }
}
