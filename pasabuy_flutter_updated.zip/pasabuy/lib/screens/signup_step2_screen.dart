import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/app_text_field.dart';
import '../widgets/auth_scaffold.dart';
import '../widgets/step_progress.dart';
import 'signup_step3_screen.dart';

/// Create Account Screen Step 2 — base address with a full-width map.
class SignupStep2Screen extends StatelessWidget {
  const SignupStep2Screen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    return AuthScaffold(
      padding: const EdgeInsets.fromLTRB(34.5, 62.95, 34.5, 32),
      swooshOffset: const Offset(-1.18, -0.77),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AuthBackButton(),
          const SizedBox(height: 29),
          const StepProgress(step: 2),
          const SizedBox(height: 29),
          Text('Set your Location', style: AppText.bold(32)),
          const SizedBox(height: 8),
          Text(
            'This helps us match you with nearby shoppers.',
            style: AppText.regular(14, AppColors.bodyText),
          ),
          const SizedBox(height: 14),
          // The map bleeds past the 34.5px side padding to the screen edges.
          SizedBox(
            height: 240,
            child: OverflowBox(
              minWidth: screenWidth,
              maxWidth: screenWidth,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  color: Colors.white,
                  width: screenWidth,
                  height: 240,
                  child: Image.asset(AppAssets.signupMap, fit: BoxFit.cover),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text('Your Base Address', style: AppText.medium(14)),
          const SizedBox(height: 8),
          Text(
            'Drag the map or type to change your address',
            style: AppText.regular(12, AppColors.bodyText),
          ),
          const SizedBox(height: 8),
          const AppTextField(
            hint: 'Search your address',
            initialValue: 'Plaza Rizal St, Jaro, Iloilo City, 5000 Iloilo',
            iconAsset: AppAssets.mapPin,
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: 'Next',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SignupStep3Screen()),
            ),
          ),
        ],
      ),
    );
  }
}
