import 'package:flutter/material.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/auth_scaffold.dart';
import '../widgets/step_progress.dart';
import 'home_shell.dart';

/// Create Account Screen Step 3 — pick the default role.
class SignupStep3Screen extends StatefulWidget {
  const SignupStep3Screen({super.key});

  @override
  State<SignupStep3Screen> createState() => _SignupStep3ScreenState();
}

class _SignupStep3ScreenState extends State<SignupStep3Screen> {
  PasabuyRole _selected = PasabuyRole.shopper;

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      padding: const EdgeInsets.fromLTRB(34.5, 60.04, 34.5, 32),
      swooshOffset: const Offset(0, -0.77),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AuthBackButton(),
          const SizedBox(height: 29),
          const StepProgress(step: 3),
          const SizedBox(height: 29),
          Text('How will you use Pasabuy?', style: AppText.bold(32)),
          const SizedBox(height: 8),
          Text(
            'Pick your default role. You can switch anytime from the app.',
            style: AppText.regular(14, AppColors.bodyText),
          ),
          const SizedBox(height: 20),
          _RoleCard(
            illustration: Image.asset(AppAssets.roleRequester, width: 65.686, height: 69.486),
            title: 'Requester',
            titleColor: AppColors.bodyText,
            description:
                'I request items for nearby shoppers already heading to the store. Fast, easy, no need to go out',
            selected: _selected == PasabuyRole.requester,
            onTap: () => setState(() => _selected = PasabuyRole.requester),
          ),
          const SizedBox(height: 20),
          _RoleCard(
            illustration: Image.asset(AppAssets.roleShopper, width: 66, height: 67.923),
            title: 'Shopper',
            titleColor: AppColors.roleTitleAlt,
            description:
                'I go to store and hitch items for others nearby. I earn by delivering their items on my way back.',
            selected: _selected == PasabuyRole.shopper,
            onTap: () => setState(() => _selected = PasabuyRole.shopper),
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: 'Get Started',
            onPressed: () {
              AppState.mode.value = _selected;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const HomeShell()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}

/// 321 x 122 role card. Selected: 1px purple border + filled check;
/// unselected: 0.5px grey border + empty ring.
class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.illustration,
    required this.title,
    required this.titleColor,
    required this.description,
    required this.selected,
    required this.onTap,
  });

  final Widget illustration;
  final String title;
  final Color titleColor;
  final String description;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        height: 122,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.roleCardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.roleCardBorder,
            width: selected ? 1 : 0.5,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            illustration,
            SizedBox(
              width: 168,
              height: 93,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(title, style: AppText.medium(20, titleColor)),
                  Text(
                    description,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: AppText.regular(14, AppColors.bodyText),
                  ),
                ],
              ),
            ),
            selected
                ? const AppSvg(AppAssets.checkCircle, width: 21, height: 21)
                : Container(
                    width: 21,
                    height: 21,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.radioBorder),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
