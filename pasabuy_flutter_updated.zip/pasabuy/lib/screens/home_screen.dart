import 'package:flutter/material.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_icon.dart';
import '../widgets/common.dart';
import '../widgets/layout.dart';
import 'chat_detail_screen.dart';

/// Home — the map view for both modes.
///  * Shopper: "Where do you want to shop?" marker; tapping it opens the
///    Quick Tray (Shopper POV) listing nearby requests.
///  * Requester: "What are the items you need?" marker plus the bottom sheet of
///    nearby shoppers (Quick Tray, Requester POV).
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PasabuyRole>(
      valueListenable: AppState.mode,
      builder: (context, mode, _) {
        return ColoredBox(
          color: AppColors.bgApp,
          child: Column(
            children: [
              SizedBox(height: screenTopPadding(context)),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: _HomeHeader(),
              ),
              const SizedBox(height: 16),
              _ModePill(mode: mode),
              const SizedBox(height: 16),
              Expanded(child: _MapArea(mode: mode)),
            ],
          ),
        );
      },
    );
  }
}

class _HomeHeader extends StatelessWidget {
  const _HomeHeader();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 24,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Image.asset(AppAssets.wordmark, width: 82.899, height: 22.846, fit: BoxFit.contain),
          const AppSvg(AppAssets.bell, width: 16.591, height: 20.739),
        ],
      ),
    );
  }
}

/// White "Current Mode: Shopper" pill.
class _ModePill extends StatelessWidget {
  const _ModePill({required this.mode});

  final PasabuyRole mode;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border10, width: 0.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Current Mode:', style: AppText.regular(14, AppColors.primary)),
          const SizedBox(width: 10),
          Text(mode.label, style: AppText.medium(14, AppColors.primary)),
        ],
      ),
    );
  }
}

class _MapArea extends StatelessWidget {
  const _MapArea({required this.mode});

  final PasabuyRole mode;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
      child: ColoredBox(
        color: Colors.white,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final markersLeft = (constraints.maxWidth - 390) / 2 + 24;
            return Stack(
              fit: StackFit.expand,
              children: [
                Positioned.fill(
                  child: Image.asset(
                    AppAssets.homeMap,
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                  ),
                ),
                Positioned(
                  left: markersLeft,
                  top: 149.38,
                  width: 342.252,
                  height: 342.252,
                  child: _Markers(mode: mode),
                ),
                if (mode == PasabuyRole.requester)
                  DraggableScrollableSheet(
                    initialChildSize: (365 / constraints.maxHeight).clamp(0.1, 0.9),
                    minChildSize: (60 / constraints.maxHeight).clamp(0.05, 0.5),
                    maxChildSize: 0.9,
                    builder: (context, controller) => SheetSurface(
                      child: _SheetList(
                        controller: controller,
                        cards: _nearbyShoppers
                            .map((p) => PersonCard(
                                  name: p.name,
                                  distance: p.distance,
                                  detail: p.detail,
                                  onTap: () => Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          const ChatDetailScreen(variant: ChatVariant.shopperRequest),
                                    ),
                                  ),
                                ))
                            .toList(),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Handle + list of cards inside a sheet (24px under the handle, 8px apart).
class _SheetList extends StatelessWidget {
  const _SheetList({required this.cards, this.controller});

  final List<Widget> cards;
  final ScrollController? controller;

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: controller,
      padding: EdgeInsets.zero,
      children: [
        const Center(child: AppSvg(AppAssets.sheetHandle, width: 40, height: 3)),
        const SizedBox(height: 24),
        for (var i = 0; i < cards.length; i++) ...[
          if (i > 0) const SizedBox(height: 8),
          Center(child: cards[i]),
        ],
        const SizedBox(height: 16),
      ],
    );
  }
}

class _Markers extends StatelessWidget {
  const _Markers({required this.mode});

  final PasabuyRole mode;

  @override
  Widget build(BuildContext context) {
    final isShopper = mode == PasabuyRole.shopper;
    // Positions are taken from Figma "Frame 63" (342 x 342).
    final center = isShopper ? const Offset(189.5, 171.44) : const Offset(171.13, 171.11);
    final tooltipTop = isShopper ? 100.96 : 100.63;
    final bubbleWidth = isShopper ? 97.0 : 107.15;
    final plus = isShopper ? const Offset(227, 89.96) : const Offset(213.7, 89.63);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        const Positioned(left: 243.13, top: 72.17, child: _PersonPin(distance: '75 m')),
        const Positioned(left: 123.13, top: 2.17, child: _PersonPin(distance: '81 m')),
        const Positioned(left: 153.13, top: 232.17, child: _PersonPin(distance: '49 m')),
        const Positioned(left: 63.13, top: 152.17, child: _PersonPin(distance: '47 m')),
        // "You are here" dot: 26px purple disc, 2px white ring, white glow.
        Positioned(
          left: center.dx - 15.04,
          top: center.dy - 15.04,
          child: GestureDetector(
            onTap: isShopper ? () => _openShopperTray(context) : null,
            child: Container(
              width: 30.08,
              height: 30.08,
              decoration: BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xA8FFFFFF), width: 2),
                boxShadow: const [BoxShadow(color: Colors.white, blurRadius: 14.5)],
              ),
            ),
          ),
        ),
        Positioned(
          left: center.dx - bubbleWidth / 2,
          top: tooltipTop,
          width: bubbleWidth,
          child: GestureDetector(
            onTap: isShopper ? () => _openShopperTray(context) : null,
            child: _Tooltip(
              text: isShopper ? 'Where do you want to shop?' : 'What are the items you need?',
              textWidth: bubbleWidth - 16,
            ),
          ),
        ),
        Positioned(
          left: plus.dx,
          top: plus.dy,
          child: GestureDetector(
            // Hooks for the "add location" / "add items" flows.
            onTap: () {},
            child: const AppSvg(AppAssets.plusBadge, width: 22, height: 22),
          ),
        ),
      ],
    );
  }

  void _openShopperTray(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) => SizedBox(
        height: 481,
        child: SheetSurface(
          topPadding: 12,
          child: _SheetList(
            cards: _nearbyRequests
                .map((p) => PersonCard(
                      name: p.name,
                      distance: p.distance,
                      detail: p.detail,
                      trailing: 'View items',
                      onTap: () {
                        Navigator.of(sheetContext).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const ChatDetailScreen()),
                        );
                      },
                    ))
                .toList(),
          ),
        ),
      ),
    );
  }
}

/// Purple speech bubble with a downward tail (12px Medium white text).
class _Tooltip extends StatelessWidget {
  const _Tooltip({required this.text, required this.textWidth});

  final String text;
  final double textWidth;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(7),
          ),
          child: SizedBox(
            width: textWidth,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: AppText.medium(12, Colors.white).copyWith(letterSpacing: -0.36),
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(0, -3),
          child: const AppSvg(AppAssets.tooltipTail, width: 13, height: 9),
        ),
      ],
    );
  }
}

/// Avatar ringed in purple with a white distance chip underneath.
class _PersonPin extends StatelessWidget {
  const _PersonPin({required this.distance});

  final String distance;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 47,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.primary),
            ),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.pinAvatarBg,
                border: Border.all(color: Colors.white),
              ),
              child: ClipOval(child: Image.asset(AppAssets.avatarDefault, fit: BoxFit.cover)),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            height: 20,
            width: 47,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(11),
              boxShadow: const [
                BoxShadow(color: Color(0x0D000000), blurRadius: 1, offset: Offset(0, 2)),
              ],
            ),
            child: Text(
              distance,
              style: AppText.medium(12, AppColors.primary).copyWith(letterSpacing: -0.36),
            ),
          ),
        ],
      ),
    );
  }
}

class _Nearby {
  const _Nearby(this.name, this.distance, this.detail);
  final String name;
  final String distance;
  final String detail;
}

const _nearbyShoppers = [
  _Nearby('Mikaela Surname', '85m', 'Going to SM City Iloilo'),
  _Nearby('Mikaela Surname', '62m', 'Going to Robinson’s Place Jaro'),
  _Nearby('Mikaela Surname', '25m', 'Going to Lapaz Public Market'),
];

const _nearbyRequests = [
  _Nearby('Mikaela Surname', '85m', '6 Items'),
  _Nearby('Mikaela Surname', '62m', '3 Items'),
  _Nearby('Mikaela Surname', '25m', '1 Item'),
];
