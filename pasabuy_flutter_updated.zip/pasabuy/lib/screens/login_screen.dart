import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/app_text_field.dart';
import '../widgets/auth_scaffold.dart';
import 'home_shell.dart';
import 'signup_step1_screen.dart';

/// Log in Screen.
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Login', style: AppText.bold(32)),
          const SizedBox(height: 14),
          Row(
            children: [
              Text('Don’t have an account? ', style: AppText.regular(14, AppColors.bodyText)),
              const SizedBox(width: 5),
              GestureDetector(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SignupStep1Screen()),
                ),
                child: Text('Sign up', style: AppText.regular(14, AppColors.primary)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const AppTextField(
            hint: 'Email',
            iconAsset: AppAssets.mail,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 14),
          const AppTextField(hint: 'Password', iconAsset: AppAssets.lock, obscure: true),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () {},
            child: Text('Forgot password?', style: AppText.regular(14, AppColors.primary)),
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: 'Login',
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const HomeShell()),
              (route) => false,
            ),
          ),
        ],
      ),
    );
  }
}
