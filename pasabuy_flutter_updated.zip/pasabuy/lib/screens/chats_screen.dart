import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';
import 'chat_detail_screen.dart';

/// Chats tab — filters plus the conversation list.
class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _Conversation {
  const _Conversation(this.name, this.preview, this.tag, this.time, {this.unread = false});
  final String name;
  final String preview;
  final String tag; // "Shopper" or "Requester"
  final String time;
  final bool unread;
}

class _ChatsScreenState extends State<ChatsScreen> {
  int _filter = 0;

  static const _conversations = [
    _Conversation('Mikaela Surname', 'Shopping your items at SM City Iloilo • 5 items', 'Shopper', '9:35 AM'),
    _Conversation('Mark Surname', 'Need: Milk, Bread, Egg\nSee you in a bit!', 'Requester', '10:01 AM'),
  ];

  bool _visible(_Conversation c) => switch (_filter) {
        1 => c.tag == 'Requester', // Buyers
        2 => c.tag == 'Shopper', // Sellers
        3 => c.unread,
        _ => true,
      };

  @override
  Widget build(BuildContext context) {
    final items = _conversations.where(_visible).toList();
    return ColoredBox(
      color: AppColors.bgCanvas,
      child: ListView(
        padding: EdgeInsets.fromLTRB(20, screenTopPadding(context), 20, 20),
        children: [
          const TabHeader(title: 'Chats'),
          const SizedBox(height: 16),
          FilterPills(
            labels: const [' All', 'Buyers', 'Sellers', 'Unread'],
            height: 39,
            selected: _filter,
            onSelected: (i) => setState(() => _filter = i),
          ),
          for (final c in items) ...[
            const SizedBox(height: 16),
            _ConversationTile(
              conversation: c,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ChatDetailScreen()),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ConversationTile extends StatelessWidget {
  const _ConversationTile({required this.conversation, required this.onTap});

  final _Conversation conversation;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: SizedBox(
        height: 92,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 55,
              height: 54,
              decoration: const BoxDecoration(color: AppColors.chatAvatarBg, shape: BoxShape.circle),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(conversation.name, style: AppText.medium(16)),
                  SizedBox(
                    width: 145.07,
                    child: Text(
                      conversation.preview,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppText.regular(14, AppColors.muted),
                    ),
                  ),
                  Container(
                    height: 24,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: AppColors.chipPurpleBg,
                      borderRadius: BorderRadius.circular(74),
                      border: Border.all(color: AppColors.border05, width: 0.5),
                    ),
                    child: Center(
                      widthFactor: 1,
                      child: Text(conversation.tag, style: AppText.medium(12, AppColors.primary)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 15),
            SizedBox(
              width: 97,
              child: Text(
                conversation.time,
                textAlign: TextAlign.right,
                style: AppText.regular(14, AppColors.muted),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
