import 'package:flutter/material.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';
import 'order_information_screen.dart';

/// Orders tab — active orders, each opening Order Information for the
/// current mode (requester or shopper view).
class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    void open() => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => OrderInformationScreen(
              variant: AppState.mode.value == PasabuyRole.requester
                  ? OrderVariant.requester
                  : OrderVariant.shopper,
            ),
          ),
        );

    return ColoredBox(
      color: AppColors.bgApp,
      child: ListView(
        padding: EdgeInsets.fromLTRB(20, screenTopPadding(context), 20, 20),
        children: [
          const TabHeader(title: 'Orders'),
          const SizedBox(height: 16),
          RecordCard(
            title: 'Trip for [Name]',
            store: 'Store Name',
            items: '6 items',
            status: OrderStatus.inProgress,
            time: '10:24 AM',
            amount: '₱----',
            amountLabel: 'Profit',
            onTap: open,
          ),
          const SizedBox(height: 16),
          RecordCard(
            title: 'Trip for [Name]',
            store: 'Store Name',
            items: '6 items',
            status: OrderStatus.inProgress,
            time: '10:24 AM',
            amount: '₱0.00',
            amountLabel: 'Earned',
            onTap: open,
          ),
        ],
      ),
    );
  }
}
