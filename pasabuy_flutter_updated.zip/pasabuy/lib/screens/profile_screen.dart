import 'package:flutter/material.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_icon.dart';
import '../widgets/layout.dart';
import 'login_screen.dart';

/// Profile tab — user card, wallet, mode switch and account settings.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: AppColors.bgCanvas,
      child: ListView(
        padding: EdgeInsets.fromLTRB(20, screenTopPadding(context), 20, 20),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Profile', style: AppText.medium(20)),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                ),
                child: const AppPng(AppAssets.logout, width: 18.935, height: 19.27),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const _UserRow(),
          const SizedBox(height: 14),
          const _WalletCard(),
          const SizedBox(height: 14),
          const _ModeSwitch(),
          const SizedBox(height: 14),
          SizedBox(height: 24, child: Text('Account', style: AppText.medium(16))),
          const SizedBox(height: 14),
          const _AccountRow(
            icon: AppSvg(AppAssets.personOutline, width: 12.667, height: 12.667),
            gap: 14,
            label: 'Manage Profile ',
          ),
          const SizedBox(height: 4),
          const _AccountRow(
            icon: AppSvg(AppAssets.pinOutline, width: 10.75, height: 12.917),
            gap: 13.5,
            label: 'Base Adress',
          ),
          const SizedBox(height: 4),
          const _AccountRow(
            icon: AppPng(AppAssets.mailOutline, width: 14, height: 12.843),
            gap: 14,
            label: 'Email Adress',
          ),
          const SizedBox(height: 4),
          const _AccountRow(
            icon: AppSvg(AppAssets.phoneOutline, width: 12.956, height: 12.98),
            gap: 13.5,
            label: 'Phone Number',
          ),
          const SizedBox(height: 14),
          Text('Current Activity', style: AppText.medium(16)),
        ],
      ),
    );
  }
}

class _UserRow extends StatelessWidget {
  const _UserRow();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 12),
      child: Row(
        children: [
          SizedBox(
            width: 107,
            height: 108,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 107,
                  height: 108,
                  decoration: const BoxDecoration(
                    color: AppColors.profileAvatarBg,
                    borderRadius: BorderRadius.all(Radius.circular(515)),
                  ),
                ),
                Positioned(
                  left: 75,
                  top: 76,
                  child: GestureDetector(
                    onTap: () {},
                    child: Container(
                      width: 36,
                      height: 36,
                      alignment: Alignment.center,
                      decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                      child: const AppSvg(AppAssets.camera, width: 16, height: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 20),
          SizedBox(
            width: 130.75,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Juan Dela Cruz', style: AppText.medium(18)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const AppSvg(AppAssets.locSmall, width: 11.25, height: 13.42),
                    const SizedBox(width: 7.25),
                    Text('Iloilo City, Philippines ', style: AppText.regular(12)),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const AppSvg(AppAssets.calendar, width: 12.22, height: 12.83),
                    const SizedBox(width: 7.35),
                    Text('Member since 2026', style: AppText.regular(12)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WalletCard extends StatelessWidget {
  const _WalletCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border10, width: 0.5),
        gradient: const LinearGradient(
          // 51.16deg, #7C3AED 50% -> #A672FF 152.48%
          begin: Alignment(-0.78, 0.63),
          end: Alignment(0.78, -0.63),
          // Colour at 100% of the CSS line (the end stop sits beyond the box).
          colors: [AppColors.primary, AppColors.primary, Color(0xFF9055F6)],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
      child: SizedBox(
        height: 62,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Wallet Balance', style: AppText.regular(14, Colors.white)),
                Opacity(
                  opacity: 0.75,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 40,
                        child: Text('Gcash', textAlign: TextAlign.center, style: AppText.regular(12, Colors.white)),
                      ),
                      const SizedBox(width: 12),
                      const AppSvg(AppAssets.chevronSmallWhite, width: 5.9, height: 11),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('₱ 500.00', style: AppText.semibold(32, Colors.white)),
          ],
        ),
      ),
    );
  }
}

/// "Need Something" / "Going Shopping" segmented switch bound to the app mode.
class _ModeSwitch extends StatelessWidget {
  const _ModeSwitch();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PasabuyRole>(
      valueListenable: AppState.mode,
      builder: (context, mode, _) {
        final requester = mode == PasabuyRole.requester;
        return Container(
          height: 52,
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: AppColors.bgApp,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border10, width: 0.5),
          ),
          child: Row(
            children: [
              Expanded(
                child: _ModeSegment(
                  label: 'Need Something',
                  selected: requester,
                  icon: (c) => AppPng(AppAssets.cart, width: 14, height: 15.5, color: c),
                  onTap: () => AppState.mode.value = PasabuyRole.requester,
                ),
              ),
              const SizedBox(width: 1),
              Expanded(
                child: _ModeSegment(
                  label: 'Going Shopping',
                  selected: !requester,
                  icon: (c) => AppSvg(AppAssets.walk, width: 11.33, height: 16, color: c),
                  onTap: () => AppState.mode.value = PasabuyRole.shopper,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ModeSegment extends StatelessWidget {
  const _ModeSegment({
    required this.label,
    required this.selected,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final Widget Function(Color color) icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final fg = selected ? Colors.white : AppColors.textDark;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 43,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: selected ? null : AppColors.bgApp,
          gradient: selected
              ? const LinearGradient(
                  // 253.94deg, #7C3AED 50% -> #A672FF 201.6%
                  begin: Alignment(0.96, -0.28),
                  end: Alignment(-0.96, 0.28),
                  colors: [AppColors.primary, AppColors.primary, Color(0xFF8A4DF3)],
                  stops: [0.0, 0.5, 1.0],
                )
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon(selected ? Colors.white : AppColors.primary),
            const SizedBox(width: 10),
            Text(label, style: AppText.regular(14, fg)),
          ],
        ),
      ),
    );
  }
}

class _AccountRow extends StatelessWidget {
  const _AccountRow({required this.icon, required this.gap, required this.label});

  final Widget icon;
  final double gap;
  final String label;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border10, width: 0.5),
        ),
        child: Row(
          children: [
            icon,
            SizedBox(width: gap),
            Expanded(child: Text(label, style: AppText.regular(14))),
            const AppSvg(AppAssets.chevronRight, width: 9, height: 15),
          ],
        ),
      ),
    );
  }
}
