import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/app_icon.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';
import 'order_information_screen.dart';

enum ChatVariant {
  /// "Chats" frame: trip card, quick actions and the message composer.
  active,

  /// "Frame 191": a shopper is asking to shop for you — Accept / Decline.
  shopperRequest,
}

class _Message {
  const _Message(this.text, this.time, {required this.outgoing});
  final String text;
  final String time;
  final bool outgoing;
}

/// Conversation screen.
class ChatDetailScreen extends StatefulWidget {
  const ChatDetailScreen({super.key, this.variant = ChatVariant.active});

  final ChatVariant variant;

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  late ChatVariant _variant = widget.variant;
  final _composer = TextEditingController();
  final _scroll = ScrollController();

  final List<_Message> _messages = [
    const _Message('Message here', '2:00pm', outgoing: false),
    const _Message('Message here', '2:00pm', outgoing: true),
    const _Message('Message here', '2:00pm', outgoing: false),
    const _Message('Message here', '2:00pm', outgoing: false),
    const _Message('Message here', '2:00pm', outgoing: true),
  ];

  @override
  void dispose() {
    _composer.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final text = _composer.text.trim();
    if (text.isEmpty) return;
    final now = TimeOfDay.now();
    final hour = now.hourOfPeriod == 0 ? 12 : now.hourOfPeriod;
    final time = '$hour:${now.minute.toString().padLeft(2, '0')}${now.period == DayPeriod.am ? 'am' : 'pm'}';
    setState(() => _messages.add(_Message(text, time, outgoing: true)));
    _composer.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isRequest = _variant == ChatVariant.shopperRequest;
    final messageList = ListView.separated(
      controller: _scroll,
      padding: EdgeInsets.zero,
      itemCount: _messages.length,
      separatorBuilder: (_, __) => const SizedBox(height: 16),
      itemBuilder: (_, i) {
        final m = _messages[i];
        return Align(
          alignment: m.outgoing ? Alignment.centerRight : Alignment.centerLeft,
          child: m.outgoing ? _OutgoingBubble(m.text, m.time) : _IncomingBubble(m.text, m.time),
        );
      },
    );

    return Scaffold(
      backgroundColor: AppColors.bgCanvas,
      resizeToAvoidBottomInset: true,
      body: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          screenTopPadding(context),
          20,
          math.max(20.0, MediaQuery.paddingOf(context).bottom + 8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _ChatHeader(),
            const SizedBox(height: 16),
            if (!isRequest) ...[
              const _TripCard(),
              const SizedBox(height: 16),
            ],
            Expanded(
              child: isRequest
                  ? Stack(
                      children: [
                        Positioned.fill(child: messageList),
                        Positioned(
                          left: 0,
                          right: 0,
                          top: 0,
                          child: _RequestCard(
                            onAccept: () => setState(() => _variant = ChatVariant.active),
                            onDecline: () => Navigator.of(context).maybePop(),
                          ),
                        ),
                      ],
                    )
                  : messageList,
            ),
            if (!isRequest) ...[
              const SizedBox(height: 8),
              const _QuickAction(icon: AppAssets.editList, iconSize: Size(18, 13), label: 'Edit your list'),
              const SizedBox(height: 8),
              const _QuickAction(icon: AppAssets.cameraPurple, iconSize: Size(18, 16), label: 'Take a picture'),
              const SizedBox(height: 8),
              _Composer(controller: _composer, onSend: _send),
            ],
          ],
        ),
      ),
    );
  }
}

class _ChatHeader extends StatelessWidget {
  const _ChatHeader();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44.303,
      child: Stack(
        children: [
          Row(
            children: [
              const BackChevron(),
              const SizedBox(width: 17),
              const AvatarPlaceholder(),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Mikaela Surname', style: AppText.medium(14, Colors.black)),
                    const SizedBox(height: 1),
                    Text('online', style: AppText.medium(10, AppColors.online)),
                  ],
                ),
              ),
              GestureDetector(onTap: () {}, child: const AppSvg(AppAssets.phoneFill, width: 17, height: 17)),
              const SizedBox(width: 20),
              GestureDetector(onTap: () {}, child: const AppSvg(AppAssets.dotsVertical, width: 4, height: 18)),
              const SizedBox(width: 4),
            ],
          ),
          const BackHitArea(height: 44.303),
        ],
      ),
    );
  }
}

/// Frosted white card used for the trip summary and the shopper request.
class _FrostedCard extends StatelessWidget {
  const _FrostedCard({required this.child, required this.padding});

  final Widget child;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Color(0x0D000000), blurRadius: 6, offset: Offset(0, 2))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Container(
            width: double.infinity,
            padding: padding,
            color: const Color(0x80FFFFFF),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _TripCard extends StatelessWidget {
  const _TripCard();

  @override
  Widget build(BuildContext context) {
    return _FrostedCard(
      padding: const EdgeInsets.symmetric(horizontal: 15.5, vertical: 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Shopping Trip', style: AppText.medium(12, AppColors.primary)),
              const SizedBox(width: 4),
              const StatusPill(OrderStatus.inProgress),
              const Spacer(),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => OrderInformationScreen(
                      variant: AppState.mode.value == PasabuyRole.requester
                          ? OrderVariant.requester
                          : OrderVariant.shopper,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Text('View details', style: AppText.medium(12, AppColors.muted)),
                    const SizedBox(width: 5),
                    const AppSvg(AppAssets.viewChevron, width: 6, height: 10),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          Text('SM City Iloilo • 5 items', style: AppText.medium(12, Colors.black)),
        ],
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({required this.onAccept, required this.onDecline});

  final VoidCallback onAccept;
  final VoidCallback onDecline;

  @override
  Widget build(BuildContext context) {
    Widget button(String label, Color color, VoidCallback onTap) => Expanded(
          child: GestureDetector(
            onTap: onTap,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)),
              child: Text(label, style: AppText.medium(12, Colors.white)),
            ),
          ),
        );

    return _FrostedCard(
      padding: const EdgeInsets.all(19),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const AvatarPlaceholder(),
              const SizedBox(width: 16),
              Expanded(
                child: SizedBox(
                  height: 53,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(text: 'Mikaela Surname ', style: AppText.medium(14, Colors.black)),
                            TextSpan(text: 'requested to shop for you', style: AppText.regular(14, Colors.black)),
                          ],
                        ),
                      ),
                      Text('Going to SM City Iloilo', style: AppText.medium(12, Colors.black)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              button('Accept', AppColors.success, onAccept),
              const SizedBox(width: 8),
              button('Decline', AppColors.decline, onDecline),
            ],
          ),
        ],
      ),
    );
  }
}

TextStyle get _bubbleTextStyle =>
    AppText.regular(14, AppColors.bubbleText).copyWith(height: 22 / 14, letterSpacing: -0.408);

/// White incoming bubble with the curled tail on the bottom-left.
class _IncomingBubble extends StatelessWidget {
  const _IncomingBubble(this.text, this.time);

  final String text;
  final String time;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 3),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 260),
            padding: const EdgeInsets.fromLTRB(15, 12, 16, 12),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: AppColors.border15, width: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Flexible(child: Text(text, style: _bubbleTextStyle)),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    time,
                    style: AppText.regular(8, AppColors.bubbleTime).copyWith(letterSpacing: -0.408),
                  ),
                ),
              ],
            ),
          ),
        ),
        const Positioned(
          left: 0,
          bottom: -1,
          child: AppSvg(AppAssets.bubbleTailIn, width: 19, height: 17),
        ),
      ],
    );
  }
}

/// Purple outgoing bubble with the tail on the bottom-right and read ticks.
class _OutgoingBubble extends StatelessWidget {
  const _OutgoingBubble(this.text, this.time);

  final String text;
  final String time;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 3),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 260),
            padding: const EdgeInsets.fromLTRB(16, 12, 15, 12),
            decoration: BoxDecoration(
              color: AppColors.primary,
              border: Border.all(color: AppColors.border15, width: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(24),
                bottomLeft: Radius.circular(24),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Flexible(
                  child: Text(
                    text,
                    textAlign: TextAlign.right,
                    style: _bubbleTextStyle.copyWith(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        time,
                        style: AppText.regular(8, Colors.white).copyWith(letterSpacing: -0.408),
                      ),
                      const SizedBox(width: 4),
                      const AppSvg(AppAssets.read, width: 12, height: 12),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const Positioned(
          right: 0,
          bottom: -1,
          child: AppSvg(AppAssets.bubbleTailOut, width: 19, height: 17),
        ),
      ],
    );
  }
}

/// White pill shortcut ("Edit your list", "Take a picture").
class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.iconSize, required this.label});

  final String icon;
  final Size iconSize;
  final String label;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        height: 45,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(43),
          border: Border.all(color: AppColors.border15, width: 0.5),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppSvg(icon, width: iconSize.width, height: iconSize.height),
            const SizedBox(width: 10),
            Text(label, style: AppText.regular(14, AppColors.primary)),
          ],
        ),
      ),
    );
  }
}

class _Composer extends StatelessWidget {
  const _Composer({required this.controller, required this.onSend});

  final TextEditingController controller;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 3),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {},
            child: const AppSvg(AppAssets.arrowUpButton, width: 45, height: 45),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 45,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(36),
                border: Border.all(color: AppColors.border10, width: 0.5),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      cursorColor: AppColors.primary,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => onSend(),
                      style: AppText.regular(12, AppColors.textDark),
                      decoration: InputDecoration(
                        hintText: 'Type message here...',
                        hintStyle: AppText.regular(12, AppColors.muted),
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: onSend,
                    child: const AppSvg(AppAssets.send, width: 18, height: 18),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
