import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/app_buttons.dart';
import '../widgets/app_icon.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';

enum PaymentChoice { gcashPartial, gcashFull, cod }

/// Payment Option — GCash (partial / full) or Cash on Delivery.
class PaymentOptionScreen extends StatefulWidget {
  const PaymentOptionScreen({super.key});

  @override
  State<PaymentOptionScreen> createState() => _PaymentOptionScreenState();
}

class _PaymentOptionScreenState extends State<PaymentOptionScreen> {
  PaymentChoice? _choice;
  bool _gcashExpanded = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgCanvas,
      body: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          screenTopPadding(context),
          20,
          math.max(36.0, MediaQuery.paddingOf(context).bottom + 12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const DetailHeader(title: 'Payment Option'),
            const SizedBox(height: 16),
            Text('Payment Method', style: AppText.medium(16, Colors.black)),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _gcashCard(),
                    const SizedBox(height: 8),
                    _codCard(),
                  ],
                ),
              ),
            ),
            PrimaryButton(
              label: 'Select',
              onPressed: _choice == null ? null : () => Navigator.of(context).pop(_choice),
            ),
          ],
        ),
      ),
    );
  }

  Widget _gcashCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(13, 11, 13, 16),
      decoration: _cardDecoration,
      child: Column(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _gcashExpanded = !_gcashExpanded),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 9),
              child: Row(
                children: [
                  const AppPng(AppAssets.gcash, width: 27, height: 24),
                  const SizedBox(width: 12),
                  Text('Gcash', style: AppText.regular(16, Colors.black)),
                  const Spacer(),
                  AnimatedRotation(
                    turns: _gcashExpanded ? 0 : -0.25,
                    duration: const Duration(milliseconds: 150),
                    child: const AppSvg(AppAssets.chevronDown, width: 14, height: 8),
                  ),
                ],
              ),
            ),
          ),
          if (_gcashExpanded) ...[
            const SizedBox(height: 10),
            const HairlineDivider(),
            const SizedBox(height: 16),
            _option('Partial Payment', '₱ 135.00', PaymentChoice.gcashPartial),
            const SizedBox(height: 16),
            const HairlineDivider(),
            const SizedBox(height: 16),
            _option('Full Payment', '₱ 475.00', PaymentChoice.gcashFull),
          ],
        ],
      ),
    );
  }

  Widget _codCard() {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _choice = PaymentChoice.cod),
      child: Container(
        height: 78.5,
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
        decoration: _cardDecoration,
        child: Row(
          children: [
            const AppPng(AppAssets.cod, width: 27, height: 24.881),
            const SizedBox(width: 12),
            Text('Cash on Delivery', style: AppText.regular(16, Colors.black)),
            const Spacer(),
            _Radio(selected: _choice == PaymentChoice.cod),
          ],
        ),
      ),
    );
  }

  Widget _option(String label, String amount, PaymentChoice value) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _choice = value),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: AppText.regular(12, Colors.black)),
              const SizedBox(height: 4),
              Text(amount, style: AppText.regular(14, AppColors.muted)),
            ],
          ),
          const Spacer(),
          _Radio(selected: _choice == value),
        ],
      ),
    );
  }

  static final _cardDecoration = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(12),
    border: Border.all(color: AppColors.border15, width: 0.5),
  );
}

/// 16px radio: grey ring when empty, the purple check disc when chosen.
class _Radio extends StatelessWidget {
  const _Radio({required this.selected});

  final bool selected;

  @override
  Widget build(BuildContext context) {
    if (selected) return const AppSvg(AppAssets.checkCircle, width: 16, height: 16);
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.radioBorder),
      ),
    );
  }
}
