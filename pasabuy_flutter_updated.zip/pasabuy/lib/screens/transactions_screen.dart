import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/app_icon.dart';
import '../widgets/common.dart';
import '../widgets/headers.dart';
import '../widgets/layout.dart';
import 'order_information_screen.dart';

/// History tab — "Transactions" with filters, search and dated groups.
class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

enum _Kind { trip, order }

class _Tx {
  const _Tx(this.kind, this.status, this.time, this.amount, this.label, [this.amountColor = AppColors.muted]);
  final _Kind kind;
  final OrderStatus status;
  final String time;
  final String amount;
  final String label;
  final Color amountColor;
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  int _filter = 0;

  static const _groups = <(String, List<_Tx>)>[
    ('Today', [_Tx(_Kind.trip, OrderStatus.cancelled, '10:24 AM', '₱0.00', 'Earned')]),
    (
      'Yesterday',
      [
        _Tx(_Kind.order, OrderStatus.completed, '8:35 AM', '- ₱380.00', 'Paid', AppColors.textDark),
        _Tx(_Kind.trip, OrderStatus.completed, '10:24 AM', '+ ₱120.00', 'Earned', AppColors.success),
      ]
    ),
    ('June 25, 2026', [_Tx(_Kind.order, OrderStatus.cancelled, '8:35 AM', '₱0.00', 'Paid')]),
  ];

  bool _visible(_Tx tx) => switch (_filter) {
        1 => tx.kind == _Kind.trip,
        2 => tx.kind == _Kind.order,
        _ => true,
      };

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[
      const TabHeader(title: 'Transactions'),
      const SizedBox(height: 16),
      FilterPills(
        labels: const [' All', 'Shopping Trips', 'My Orders'],
        widths: const [76, 145, 117],
        selected: _filter,
        onSelected: (i) => setState(() => _filter = i),
      ),
      const SizedBox(height: 16),
      const _SearchRow(),
    ];

    for (final (title, items) in _groups) {
      final visible = items.where(_visible).toList();
      if (visible.isEmpty) continue;
      children
        ..add(const SizedBox(height: 16))
        ..add(Text(title, style: AppText.medium(16, Colors.black)));
      for (final tx in visible) {
        children
          ..add(const SizedBox(height: 16))
          ..add(RecordCard(
            title: tx.kind == _Kind.trip ? 'Trip for [Name]' : 'Request from [Name]',
            store: 'Store Name',
            items: '6 items',
            status: tx.status,
            time: tx.time,
            amount: tx.amount,
            amountLabel: tx.label,
            amountColor: tx.amountColor,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const OrderInformationScreen(variant: OrderVariant.history),
              ),
            ),
          ));
      }
    }

    return ColoredBox(
      color: AppColors.bgCanvas,
      child: ListView(
        padding: EdgeInsets.fromLTRB(20, screenTopPadding(context), 20, 20),
        children: children,
      ),
    );
  }
}

class _SearchRow extends StatelessWidget {
  const _SearchRow();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 45,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(36),
              border: Border.all(color: AppColors.border10, width: 0.5),
            ),
            child: Row(
              children: [
                const AppSvg(AppAssets.search, width: 18.04, height: 18.04),
                const SizedBox(width: 9),
                Expanded(
                  child: TextField(
                    cursorColor: AppColors.primary,
                    style: AppText.regular(12, AppColors.textDark),
                    decoration: InputDecoration(
                      hintText: 'Search transactions',
                      hintStyle: AppText.regular(12, AppColors.muted),
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () {},
          child: const AppSvg(AppAssets.filter, width: 45, height: 45),
        ),
        const SizedBox(width: 3),
      ],
    );
  }
}
