import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens pulled from the Pasabuy Figma file ("Colors" frame plus the
/// tones used across the screens).
class AppColors {
  AppColors._();

  // "Colors" frame
  static const primary = Color(0xFF7C3AED);
  static const accent = Color(0xFF8B5CF6);
  static const surface = Color(0xFFF5F3FF);
  static const textDark = Color(0xFF111827);

  // Backgrounds
  static const bgCanvas = Color(0xFFF6F5FA); // auth, profile, chats, transactions
  static const bgApp = Color(0xFFFBFAFE); // home, orders, chips
  static const navBg = Color(0xFFFCFCFE);
  static const roleCardBg = Color(0xFFFBFAFF);

  // Text
  static const bodyText = Color(0xFF403E43);
  static const placeholder = Color(0xFF909298);
  static const muted = Color(0xFF727273);
  static const ink = Color(0xFF0A0A0A);
  static const onSurface = Color(0xFF1D1B20);
  static const bubbleText = Color(0xFF22282B);
  static const bubbleTime = Color(0xFF7E919A);
  static const roleTitleAlt = Color(0xFF444444);

  // Lines & borders
  static const inputBorder = Color(0x80B8BABF); // rgba(184,186,191,0.5)
  static const inputBorderAlt = Color(0x80909298); // rgba(144,146,152,0.5)
  static const radioBorder = Color(0xFF8F8F8F);
  static const roleCardBorder = Color(0x808F8F8F);
  static const border10 = Color(0x1A000000); // rgba(0,0,0,0.1)
  static const border15 = Color(0x26000000); // rgba(0,0,0,0.15)
  static const border05 = Color(0x0D000000); // rgba(0,0,0,0.05)
  static const stepInactive = Color(0xFFD9CFEA);

  // Status
  static const chipPurpleBg = Color(0xFFF5EDFF);
  static const success = Color(0xFF40B437);
  static const successBg = Color(0xFFEEFFED);
  static const danger = Color(0xFFEF404C);
  static const dangerBg = Color(0xFFFDE9E8);
  static const decline = Color(0xFFE55254);
  static const online = Color(0xFF16BA20);
  static const gcashBlue = Color(0xFF007DFE);

  // Avatars & misc
  static const pinAvatarBg = Color(0xFFB797ED);
  static const chatAvatarBg = Color(0xFFE2D9F3);
  static const profileAvatarBg = Color(0xFFEA9797);
  static const trackerTop = Color(0xFFE3D3FF);
  static const gradientEnd = Color(0xFFA672FF);
}

class AppTheme {
  AppTheme._();

  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        primary: AppColors.primary,
        secondary: AppColors.accent,
        surface: Colors.white,
      ),
      scaffoldBackgroundColor: AppColors.bgCanvas,
      textTheme: GoogleFonts.robotoTextTheme().apply(
        bodyColor: AppColors.textDark,
        displayColor: AppColors.textDark,
      ),
    );

    return base.copyWith(
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: AppColors.textDark,
      ),
    );
  }
}

/// Text styles used by the Figma screens (Roboto Regular / Medium / Bold).
class AppText {
  AppText._();

  static TextStyle regular(double size, [Color color = AppColors.textDark]) =>
      GoogleFonts.roboto(fontSize: size, fontWeight: FontWeight.w400, color: color);

  static TextStyle medium(double size, [Color color = AppColors.textDark]) =>
      GoogleFonts.roboto(fontSize: size, fontWeight: FontWeight.w500, color: color);

  static TextStyle semibold(double size, [Color color = AppColors.textDark]) =>
      GoogleFonts.roboto(fontSize: size, fontWeight: FontWeight.w600, color: color);

  static TextStyle bold(double size, [Color color = AppColors.textDark]) =>
      GoogleFonts.roboto(fontSize: size, fontWeight: FontWeight.w700, color: color);
}
