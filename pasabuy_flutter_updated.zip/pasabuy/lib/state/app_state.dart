import 'package:flutter/foundation.dart';

/// The two ways someone can use Pasabuy. Picked during sign-up (step 3) and
/// switchable from the Profile screen.
enum PasabuyRole { requester, shopper }

extension PasabuyRoleLabel on PasabuyRole {
  String get label => this == PasabuyRole.requester ? 'Requester' : 'Shopper';
}

/// App-wide state shared between tabs. Kept deliberately small: the current
/// mode drives the Home map, the Orders detail screen and the Profile toggle.
class AppState {
  AppState._();

  static final ValueNotifier<PasabuyRole> mode =
      ValueNotifier<PasabuyRole>(PasabuyRole.requester);
}
