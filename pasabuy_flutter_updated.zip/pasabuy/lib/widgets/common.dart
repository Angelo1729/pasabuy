import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'app_icon.dart';

/// 0.5px rgba(0,0,0,0.15) divider used inside cards.
class HairlineDivider extends StatelessWidget {
  const HairlineDivider({super.key, this.width});

  final double? width;

  @override
  Widget build(BuildContext context) {
    return Container(width: width ?? double.infinity, height: 0.5, color: AppColors.border15);
  }
}

/// Grey 44.3px avatar placeholder from the design.
class AvatarPlaceholder extends StatelessWidget {
  const AvatarPlaceholder({super.key, this.size = 44.303});

  final double size;

  @override
  Widget build(BuildContext context) =>
      AppSvg(AppAssets.avatarPlaceholder, width: size, height: size);
}

/// Row of pill filters ("All", "Shopping Trips", ...). The selected pill is
/// solid purple; the others are #FBFAFE with a 0.5px border.
class FilterPills extends StatelessWidget {
  const FilterPills({
    super.key,
    required this.labels,
    required this.selected,
    required this.onSelected,
    this.height = 40,
    this.widths,
  });

  final List<String> labels;
  final int selected;
  final ValueChanged<int> onSelected;
  final double height;

  /// Fixed widths per pill (Transactions). When null, pills hug their label
  /// with 25px side padding (Chats).
  final List<double>? widths;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (var i = 0; i < labels.length; i++)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onSelected(i),
              child: Container(
                height: height,
                width: widths?[i],
                padding: const EdgeInsets.symmetric(horizontal: 25),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: i == selected ? AppColors.primary : AppColors.bgApp,
                  borderRadius: BorderRadius.circular(24),
                  border: i == selected ? null : Border.all(color: AppColors.border10, width: 0.5),
                ),
                child: Text(
                  labels[i],
                  maxLines: 1,
                  style: AppText.medium(12, i == selected ? AppColors.bgApp : AppColors.textDark),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

enum OrderStatus { inProgress, completed, cancelled }

/// 19px status pill: In Progress (purple), Completed (green), Cancelled (red).
class StatusPill extends StatelessWidget {
  const StatusPill(this.status, {super.key});

  final OrderStatus status;

  @override
  Widget build(BuildContext context) {
    final (label, fg, bg, width) = switch (status) {
      OrderStatus.inProgress => ('In Progress', AppColors.primary, AppColors.chipPurpleBg, 82.0),
      OrderStatus.completed => ('Completed', AppColors.success, AppColors.successBg, 80.0),
      OrderStatus.cancelled => ('Cancelled', AppColors.danger, AppColors.dangerBg, 80.0),
    };
    return Container(
      height: 19,
      width: width,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(24),
        border: status == OrderStatus.inProgress
            ? null
            : Border.all(color: AppColors.border05, width: 0.5),
      ),
      child: Text(label, maxLines: 1, style: AppText.medium(12, fg)),
    );
  }
}

/// The 99px order / transaction card used on Orders and Transactions.
class RecordCard extends StatelessWidget {
  const RecordCard({
    super.key,
    required this.title,
    required this.store,
    required this.items,
    required this.status,
    required this.time,
    required this.amount,
    required this.amountLabel,
    this.amountColor = AppColors.muted,
    this.onTap,
  });

  final String title;
  final String store;
  final String items;
  final OrderStatus status;
  final String time;
  final String amount;
  final String amountLabel;
  final Color amountColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final subStyle = AppText.regular(12, AppColors.muted).copyWith(height: 1.0993);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        height: 99,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border15, width: 0.5),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 159,
              height: 77,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppText.medium(14)),
                  Text(store, maxLines: 1, overflow: TextOverflow.ellipsis, style: subStyle),
                  Text(items, maxLines: 1, style: subStyle),
                  const Spacer(),
                  StatusPill(status),
                ],
              ),
            ),
            const Spacer(),
            SizedBox(
              width: 110,
              height: 77,
              child: Row(
                children: [
                  SizedBox(
                    width: 73,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(time, textAlign: TextAlign.right, style: AppText.regular(12, AppColors.muted)),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(amount, textAlign: TextAlign.right, style: AppText.medium(14, amountColor)),
                            const SizedBox(height: 2),
                            Text(amountLabel,
                                textAlign: TextAlign.right, style: AppText.regular(12, AppColors.muted)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  const AppSvg(AppAssets.chevronCard, width: 13, height: 14),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Person card used in the Home bottom sheet and the Quick Trays.
class PersonCard extends StatelessWidget {
  const PersonCard({
    super.key,
    required this.name,
    required this.distance,
    required this.detail,
    this.trailing,
    this.onTap,
  });

  final String name;
  final String distance;

  /// "Going to SM City Iloilo" or "6 Items".
  final String detail;

  /// "View items" on the shopper's tray.
  final String? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: 350,
        padding: const EdgeInsets.all(19),
        decoration: BoxDecoration(
          color: const Color(0x80FFFFFF),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border15, width: 0.5),
        ),
        child: Row(
          children: [
            const AvatarPlaceholder(),
            const SizedBox(width: 16),
            Expanded(
              child: SizedBox(
                height: 53,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name, style: AppText.medium(14, Colors.black)),
                        const SizedBox(height: 2),
                        Text(distance, style: AppText.regular(12, AppColors.muted)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(detail, style: AppText.regular(12, Colors.black)),
                        if (trailing != null) Text(trailing!, style: AppText.regular(12, Colors.black)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom-sheet surface (#F6F5FA, 24px top corners, grab handle).
class SheetSurface extends StatelessWidget {
  const SheetSurface({super.key, required this.child, this.topPadding = 16});

  final Widget child;
  final double topPadding;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.bgCanvas,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: AppColors.border15, width: 0.5),
      ),
      padding: EdgeInsets.fromLTRB(10, topPadding, 10, 0),
      child: child,
    );
  }
}
