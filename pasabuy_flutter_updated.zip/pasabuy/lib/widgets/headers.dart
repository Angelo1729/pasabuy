import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'app_icon.dart';

/// Tab header: 20px Medium title on the left, bell on the right
/// (Orders, Chats, Transactions).
class TabHeader extends StatelessWidget {
  const TabHeader({super.key, required this.title, this.onBell});

  final String title;
  final VoidCallback? onBell;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: AppText.medium(20)),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onBell,
          child: const AppSvg(AppAssets.bell, width: 16.591, height: 20.739),
        ),
      ],
    );
  }
}

/// Detail header: back chevron, 14px Medium title, bell — 48px tall,
/// items pinned to the top (Order Information, Payment Option).
class DetailHeader extends StatelessWidget {
  const DetailHeader({super.key, required this.title, this.onBack});

  final String title;
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: Stack(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const BackChevron(),
              Text(title, style: AppText.medium(14)),
              const AppSvg(AppAssets.bell, width: 16.591, height: 20.739),
            ],
          ),
          BackHitArea(onTap: onBack),
        ],
      ),
    );
  }
}

/// 6 x 12 black chevron (visual only; pair with [BackHitArea]).
class BackChevron extends StatelessWidget {
  const BackChevron({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      width: 6,
      height: 12,
      child: OverflowBox(
        maxWidth: 8,
        maxHeight: 14,
        child: AppSvg(AppAssets.backChevron, width: 8, height: 14),
      ),
    );
  }
}

/// Invisible 44x48 tap target over the back chevron, so the tiny icon is
/// easy to hit without shifting the header layout.
class BackHitArea extends StatelessWidget {
  const BackHitArea({super.key, this.onTap, this.height = 48});

  final VoidCallback? onTap;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 0,
      top: 0,
      width: 44,
      height: height,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap ?? () => Navigator.of(context).maybePop(),
      ),
    );
  }
}
