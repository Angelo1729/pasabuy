import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// The solid purple 47px button used for every primary action
/// (Login, Next, Get Started, Select Payment Method, Select...).
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({super.key, this.label, this.child, required this.onPressed})
      : assert(label != null || child != null);

  final String? label;

  /// Replaces the label, e.g. the scan icon on the shopper's order screen.
  final Widget? child;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.primary,
      borderRadius: BorderRadius.circular(12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onPressed,
        child: SizedBox(
          height: 47,
          width: double.infinity,
          child: Center(
            child: child ??
                Text(label!, textAlign: TextAlign.center, style: AppText.medium(14, Colors.white)),
          ),
        ),
      ),
    );
  }
}

/// Removes the default splash/highlight so taps behave like the static Figma
/// components while still being accessible.
class Tappable extends StatelessWidget {
  const Tappable({super.key, required this.child, this.onTap});

  final Widget child;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(behavior: HitTestBehavior.opaque, onTap: onTap, child: child);
  }
}
