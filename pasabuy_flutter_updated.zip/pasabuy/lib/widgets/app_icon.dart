import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// Asset paths for every icon and image exported from the Figma file.
class AppAssets {
  AppAssets._();

  static const _i = 'assets/icons';
  static const _img = 'assets/images';

  // Images
  static const logoMark = '$_img/logo_mark.png';
  static const wordmark = '$_img/wordmark.png';
  static const authSwoosh = '$_img/auth_swoosh.svg';
  static const signupMap = '$_img/signup_map.png';
  static const homeMap = '$_img/home_map.png';
  static const roleRequester = '$_img/role_requester.png';
  static const roleShopper = '$_img/role_shopper.png';
  static const avatarDefault = '$_img/avatar_default.png';

  // Auth / form icons
  static const mail = '$_i/mail.svg';
  static const lock = '$_i/lock.svg';
  static const eye = '$_i/eye.svg';
  static const person = '$_i/person.svg';
  static const phone = '$_i/phone.svg';
  static const mapPin = '$_i/map_pin.svg';
  static const backArrow = '$_i/back_arrow.svg';
  static const checkCircle = '$_i/check_circle.svg';

  // Navbar
  static const navHome = '$_i/nav_home.png';
  static const navOrders = '$_i/nav_orders.svg';
  static const navChats = '$_i/nav_chats.svg';
  static const navHistory = '$_i/nav_history.png';
  static const navProfile = '$_i/nav_profile.svg';

  // Headers & common
  static const bell = '$_i/bell.svg';
  static const backChevron = '$_i/back_chevron.svg';
  static const chevronRight = '$_i/chevron_right.svg';
  static const chevronCard = '$_i/chevron_card.svg';
  static const chevronSmallWhite = '$_i/chevron_small_white.svg';
  static const chevronDown = '$_i/chevron_down.svg';
  static const viewChevron = '$_i/view_chevron.svg';
  static const avatarPlaceholder = '$_i/avatar_placeholder.svg';
  static const sheetHandle = '$_i/sheet_handle.svg';

  // Home map
  static const tooltipTail = '$_i/tooltip_tail.svg';
  static const plusBadge = '$_i/plus_badge.svg';

  // Profile
  static const logout = '$_i/logout.png';
  static const camera = '$_i/camera.svg';
  static const locSmall = '$_i/loc_small.svg';
  static const calendar = '$_i/calendar.svg';
  static const cart = '$_i/cart.png';
  static const walk = '$_i/walk.svg';
  static const personOutline = '$_i/person_outline.svg';
  static const pinOutline = '$_i/pin_outline.svg';
  static const mailOutline = '$_i/mail_outline.png';
  static const phoneOutline = '$_i/phone_outline.svg';

  // Transactions
  static const search = '$_i/search.svg';
  static const filter = '$_i/filter.svg';

  // Orders
  static const copy = '$_i/copy.svg';
  static const trackDot = '$_i/track_dot.svg';
  static const scan = '$_i/scan.svg';
  static const actionPhone = '$_i/action_phone.svg';
  static const actionChat = '$_i/action_chat.svg';
  static const actionPin = '$_i/action_pin.svg';
  static const gcash = '$_i/gcash.png';
  static const cod = '$_i/cod.png';

  // Chat
  static const phoneFill = '$_i/phone_fill.svg';
  static const dotsVertical = '$_i/dots_vertical.svg';
  static const bubbleTailIn = '$_i/bubble_tail_in.svg';
  static const bubbleTailOut = '$_i/bubble_tail_out.svg';
  static const read = '$_i/read.svg';
  static const editList = '$_i/edit_list.svg';
  static const cameraPurple = '$_i/camera_purple.svg';
  static const arrowUpButton = '$_i/arrow_up_btn.svg';
  static const send = '$_i/send.svg';
}

/// Renders an exported Figma SVG at its native size unless told otherwise.
class AppSvg extends StatelessWidget {
  const AppSvg(this.asset, {super.key, this.width, this.height, this.color});

  final String asset;
  final double? width;
  final double? height;

  /// Optional tint. Leave null to keep the colours from the design export.
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      asset,
      width: width,
      height: height,
      colorFilter: color == null ? null : ColorFilter.mode(color!, BlendMode.srcIn),
    );
  }
}

/// Renders a 3x PNG export (used for icons whose vector export was too heavy).
class AppPng extends StatelessWidget {
  const AppPng(this.asset, {super.key, required this.width, required this.height, this.color});

  final String asset;
  final double width;
  final double height;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      asset,
      width: width,
      height: height,
      fit: BoxFit.contain,
      color: color,
      colorBlendMode: color == null ? null : BlendMode.srcIn,
      filterQuality: FilterQuality.medium,
    );
  }
}
