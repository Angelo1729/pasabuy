import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'app_icon.dart';

/// Shared shell for the onboarding screens: #F6F5FA canvas with the faint
/// lavender swoosh in the top-right corner and scrollable content on top.
class AuthScaffold extends StatelessWidget {
  const AuthScaffold({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.fromLTRB(34.5, 219, 34.5, 32),
    this.swooshOffset = Offset.zero,
  });

  final Widget child;
  final EdgeInsets padding;

  /// Small per-screen shift of the swoosh, matching each Figma frame.
  final Offset swooshOffset;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgCanvas,
      body: Stack(
        children: [
          Positioned(
            left: swooshOffset.dx,
            top: swooshOffset.dy,
            child: const AppSvg(AppAssets.authSwoosh, width: 390, height: 419),
          ),
          Positioned.fill(
            child: SingleChildScrollView(
              padding: padding,
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 321),
                  child: child,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Faded back arrow used at the top of Create Account steps 2 and 3.
class AuthBackButton extends StatelessWidget {
  const AuthBackButton({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => Navigator.of(context).maybePop(),
      child: const SizedBox(
        width: 23.333,
        height: 23.46,
        child: OverflowBox(
          maxWidth: 27,
          maxHeight: 27,
          child: AppSvg(AppAssets.backArrow, width: 27, height: 27),
        ),
      ),
    );
  }
}
