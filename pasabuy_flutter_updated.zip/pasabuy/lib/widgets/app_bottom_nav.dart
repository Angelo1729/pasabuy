import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'app_icon.dart';

/// "Navbar - Both Modes": Home, Orders, Chats, History, Profile.
/// 54px tall, #FCFCFE, 12px radius, 36px between items, 8px Medium labels.
class AppBottomNav extends StatelessWidget {
  const AppBottomNav({super.key, required this.currentIndex, required this.onTap});

  final int currentIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final items = <_NavItem>[
      _NavItem('Home', 33, (c) => AppPng(AppAssets.navHome, width: 14.33, height: 14.33, color: c)),
      _NavItem('Orders', 47.8, (c) => AppSvg(AppAssets.navOrders, color: c)),
      _NavItem('Chats', 33, (c) => AppSvg(AppAssets.navChats, color: c)),
      _NavItem('History', 33, (c) => AppPng(AppAssets.navHistory, width: 12.33, height: 13.67, color: c)),
      _NavItem('Profile', 33, (c) => AppSvg(AppAssets.navProfile, color: c)),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.navBg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
        boxShadow: [BoxShadow(color: Color(0x40000000), blurRadius: 2)],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 54,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) const SizedBox(width: 36),
                _NavButton(
                  item: items[i],
                  selected: i == currentIndex,
                  onTap: () => onTap(i),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  const _NavItem(this.label, this.width, this.icon);
  final String label;
  final double width;
  final Widget Function(Color color) icon;
}

class _NavButton extends StatelessWidget {
  const _NavButton({required this.item, required this.selected, required this.onTap});

  final _NavItem item;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.primary : AppColors.bodyText;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10, top: 10),
        child: SizedBox(
          width: item.width,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 15, child: Center(child: item.icon(color))),
              const SizedBox(height: 4),
              Text(item.label, textAlign: TextAlign.center, style: AppText.medium(8, color)),
            ],
          ),
        ),
      ),
    );
  }
}
