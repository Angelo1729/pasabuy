import 'dart:math' as math;
import 'package:flutter/widgets.dart';

/// Figma frames use a 36px top padding. On devices with a taller status bar
/// we keep the content clear of it.
double screenTopPadding(BuildContext context) =>
    math.max(36.0, MediaQuery.paddingOf(context).top + 8);
