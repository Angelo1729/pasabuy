import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Three 31.7 x 5 segments (5px apart) shown on the Create Account steps.
class StepProgress extends StatelessWidget {
  const StepProgress({super.key, required this.step, this.totalSteps = 3});

  final int step; // 1-indexed
  final int totalSteps;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(totalSteps, (i) {
        return Container(
          width: 31.684,
          height: 5,
          margin: EdgeInsets.only(right: i == totalSteps - 1 ? 0 : 5),
          decoration: BoxDecoration(
            color: i < step ? AppColors.primary : AppColors.stepInactive,
            borderRadius: BorderRadius.circular(2),
          ),
        );
      }),
    );
  }
}
