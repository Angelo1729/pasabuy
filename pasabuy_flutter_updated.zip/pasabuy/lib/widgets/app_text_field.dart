import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'app_icon.dart';

/// The white pill input used on Login, Create Account and the address field.
/// 47px tall, 0.5px border, 16px leading padding, 10px gap after the icon.
class AppTextField extends StatefulWidget {
  const AppTextField({
    super.key,
    required this.hint,
    required this.iconAsset,
    this.obscure = false,
    this.keyboardType,
    this.controller,
    this.initialValue,
    this.borderColor = AppColors.inputBorder,
  });

  final String hint;
  final String iconAsset;
  final bool obscure;
  final TextInputType? keyboardType;
  final TextEditingController? controller;
  final String? initialValue;
  final Color borderColor;

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  late bool _obscured = widget.obscure;
  late final TextEditingController _controller =
      widget.controller ?? TextEditingController(text: widget.initialValue);

  @override
  void dispose() {
    if (widget.controller == null) _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 47,
      padding: const EdgeInsets.only(left: 16, right: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(85),
        border: Border.all(color: widget.borderColor, width: 0.5),
      ),
      child: Row(
        children: [
          AppSvg(widget.iconAsset),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _controller,
              obscureText: _obscured,
              keyboardType: widget.keyboardType,
              cursorColor: AppColors.primary,
              style: AppText.regular(14, AppColors.textDark),
              decoration: InputDecoration(
                hintText: widget.hint,
                hintStyle: AppText.regular(14, AppColors.placeholder),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          if (widget.obscure)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _obscured = !_obscured),
              child: const Padding(
                padding: EdgeInsets.only(left: 8),
                child: AppSvg(AppAssets.eye),
              ),
            ),
        ],
      ),
    );
  }
}
