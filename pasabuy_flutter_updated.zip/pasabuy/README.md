# Pasabuy — Flutter App

Built from the Figma file **Pasabuy** (`IofdZau8KpMybfZx49Wz9b`).
"Hop On the Purchase." — a buy-for-me / errand delivery app for two roles:
**Requester** (needs something bought) and **Shopper** (goes to the store and
earns by delivering).

## Screens (mapped to Figma frames)

| Flutter screen | Figma frame |
|---|---|
| `splash_screen.dart` | Splash Screen |
| `login_screen.dart` | Log in Screen |
| `signup_step1_screen.dart` | Create Account Screen Step 1 |
| `signup_step2_screen.dart` | Create Account Screen Step 2 (Set your Location) |
| `signup_step3_screen.dart` | Create Account Screen Step 3 (Requester / Shopper role) |
| `home_shell.dart` + `widgets/app_bottom_nav.dart` | Navbar - Both Modes (Home, Orders, Chats, History, Profile) |
| `home_screen.dart` | Home (Shopper) / Home (Requester) + Quick Tray (Shopper POV / Requester POV) |
| `orders_screen.dart` | Ordes |
| `order_information_screen.dart` | Order [Requester's Screen], Order [Shopper's Screen], Order History |
| `payment_option_screen.dart` | Payment Option |
| `transactions_screen.dart` (History tab) | Transactions |
| `chats_screen.dart` | Chats Page |
| `chat_detail_screen.dart` | Chats (conversation) and Frame 191 (shopper request: Accept / Decline) |
| `profile_screen.dart` | Profile + Modes (Need Something / Going Shopping) |

The current mode (Requester / Shopper) is chosen in sign-up step 3, can be
switched on the Profile screen, and drives the Home map, the "Current Mode"
pill and which Order Information view opens. It lives in
`lib/state/app_state.dart`.

## Assets

Every icon, illustration, logo and map image was exported from the Figma
file into `assets/icons/` and `assets/images/` (SVG where the vector was
light, 3x PNG otherwise) and is referenced through `AppAssets` in
`lib/widgets/app_icon.dart`.

## Design tokens

Colours and text styles are in `lib/theme/app_theme.dart` (`AppColors`,
`AppText`). From the Figma "Colors" frame: Primary `#7C3AED`, Accent
`#8B5CF6`, Surface `#F5F3FF`, Text `#111827`.

## Project structure

```
lib/
  main.dart
  state/app_state.dart      # current mode (Requester / Shopper)
  theme/app_theme.dart      # colours, text styles, ThemeData
  widgets/                  # inputs, buttons, navbar, headers, cards, pills
  screens/                  # one file per screen
assets/
  icons/                    # exported Figma icons
  images/                   # logo, wordmark, illustrations, maps
```

## Running it

```bash
flutter pub get      # pulls in flutter_svg (new) and google_fonts
flutter run
```

## Notes / next steps

- The maps are the static map images from the design; swap in
  `google_maps_flutter` or `flutter_map` when wiring real locations.
- Demo data (orders, transactions, chats, wallet) is hard-coded in each
  screen — replace with API calls / state management as the backend lands.
- The "+" badges on the Home map, call buttons and account rows have empty
  `onTap` hooks ready for their flows.
